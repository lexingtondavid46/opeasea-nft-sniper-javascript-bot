var myaddress = "your wallet address" // your public wallet address
var myprivatekey = "your privatekey to address" // the privatekey of the wallet address
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet with accessibility example (hardwarewallets)
var networks = "1" //1 = ETH ,  2 = Polygon
var maxspend = "0.3" // max eth you want to spend on the NFT or polygon if you pick networks "2" Note: Make sure you have that amount in the wallet you provided.
var NFTcollectionID = "boredapeyachtclub" //the opensea collection name "https://opensea.io/collection/boredapeyachtclub" <- take this part of the url for example: "boredapeyachtclub"
